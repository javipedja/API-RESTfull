import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='unirpractica1',
    application_name='todo-list-serverless',
    app_uid='D1G3gSZ7XMxL0hZKnJ',
    org_uid='af1f9245-d6fb-4cdf-8d06-079a8a4e27b0',
    deployment_uid='0cf2138f-9289-47de-b2f1-eb8318c13bf2',
    service_name='serverless-rest-api-with-dynamodb',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='3.8.4',
    disable_frameworks_instrumentation=False
)
handler_wrapper_kwargs = {'function_name': 'serverless-rest-api-with-dynamodb-dev-list', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('todos/list.list')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
